const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });
const enc = new TextEncoder();
const hex = (buf) => [...new Uint8Array(buf)].map(x => x.toString(16).padStart(2, '0')).join('');
const unhex = (s) => new Uint8Array((s.match(/.{1,2}/g) || []).map(x => parseInt(x, 16)));
const b64url = (s) => btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
async function hmac(secret, data) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', key, enc.encode(data)));
}
async function passHash(password, saltHex) {
  const salt = saltHex ? unhex(saltHex) : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256' }, key, 256);
  return `${hex(salt)}:${hex(bits)}`;
}
async function same(a,b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let n=0; for(let i=0;i<a.length;i++) n |= a.charCodeAt(i)^b.charCodeAt(i); return n===0;
}
async function signToken(id, secret) {
  const payload = `${id}.${Date.now()+30*864e5}`;
  return `${payload}.${await hmac(secret,payload)}`;
}
async function verifyToken(token, secret) {
  const p=String(token||'').split('.'); if(p.length!==3 || !/^\d+$/.test(p[1]) || Number(p[1])<Date.now()) return null;
  return await same(await hmac(secret,`${p[0]}.${p[1]}`),p[2]) ? p[0] : null;
}
function pub(u){return {name:u.name,phone:u.phone,reg_no:u.reg_no,approved:u.approved,pay_status:u.pay_status};}
async function db(env, path, init={}) {
  if(!env.SUPABASE_URL || !env.SUPABASE_KEY) throw new Error('Database is not configured. Add SUPABASE_URL and SUPABASE_KEY in Cloudflare Pages settings.');
  const headers = new Headers(init.headers || {}); headers.set('apikey',env.SUPABASE_KEY); headers.set('authorization','Bearer '+env.SUPABASE_KEY); headers.set('content-type','application/json');
  if(init.method==='POST' || init.method==='PATCH') headers.set('Prefer','return=representation');
  const res=await fetch(env.SUPABASE_URL.replace(/\/$/,'')+'/rest/v1/'+path,{...init,headers}); const raw=await res.text();
  if(!res.ok) throw new Error(`Database request failed (${res.status}): ${raw.slice(0,250)}`);
  return raw?JSON.parse(raw):[];
}
export async function onRequestPost({request, env}) {
 try {
  const b=await request.json(), a=b.action;
  if(!env.JWT_SECRET || env.JWT_SECRET.length<32) return json({error:'Setup incomplete: add a JWT_SECRET of at least 32 characters in Cloudflare Pages settings.'},503);
  if(a==='register') {
   const name=String(b.name||'').trim().slice(0,60), phone=String(b.phone||''), password=String(b.password||'');
   if(!name || !/^[0-9]{10}$/.test(phone) || password.length<6) return json({error:'Enter your name, a valid 10-digit mobile number and a password of at least 6 characters.'},400);
   const existing=await db(env,'users?select=id&phone=eq.'+encodeURIComponent(phone));
   if(existing.length) return json({error:'This mobile number already has an account. Please log in.'},409);
   for(let i=0;i<5;i++){
    const reg='SK'+crypto.getRandomValues(new Uint32Array(1))[0].toString().slice(0,6).padStart(6,'0');
    try { const rows=await db(env,'users',{method:'POST',body:JSON.stringify({name,phone,pass_hash:await passHash(password),reg_no:reg})}); const u=rows[0]; if(!u) throw new Error('No user returned from database'); return json({token:await signToken(u.id,env.JWT_SECRET)}); }
    catch(e){ if(!String(e.message).includes('23505') && !String(e.message).includes('duplicate key')) throw e; }
   }
   return json({error:'Could not create account just now. Please try again.'},500);
  }
  if(a==='login'){
   const phone=String(b.phone||''); const rows=await db(env,'users?select=*&phone=eq.'+encodeURIComponent(phone)); const u=rows[0];
   if(!u) return json({error:'Mobile number or password is incorrect.'},401);
   const [salt, digest]=String(u.pass_hash||'').split(':');
   let valid=false; if(salt&&digest){const check=await passHash(String(b.password||''),salt);valid=await same(check.split(':')[1],digest);}
   if(!valid) return json({error:'Mobile number or password is incorrect.'},401);
   return json({token:await signToken(u.id,env.JWT_SECRET)});
  }
  if(a==='me' || a==='pay'){
   const id=await verifyToken(b.token,env.JWT_SECRET); if(!id) return json({error:'Please log in again.'},401);
   const rows=await db(env,'users?select=*&id=eq.'+encodeURIComponent(id)); const u=rows[0]; if(!u) return json({error:'Please log in again.'},401);
   if(a==='pay'){
    const txid=String(b.txid||'').trim(), net=String(b.net||''); const valid={BEP20:/^0x[0-9a-fA-F]{64}$/,TRC20:/^[0-9a-fA-F]{64}$/};
    if(!u.approved || u.pay_status!=='none' || !valid[net] || !valid[net].test(txid)) return json({error:'Choose a valid network and enter a valid transaction hash.'},400);
    const updated=await db(env,'users?id=eq.'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({pay_status:'submitted',txid:txid.toLowerCase(),net})});
    return json({user:pub(updated[0]||u),addr:{BEP20:env.USDT_BEP20||'',TRC20:env.USDT_TRC20||''},price:env.PRICE||'5'});
   }
   return json({user:pub(u),addr:{BEP20:env.USDT_BEP20||'',TRC20:env.USDT_TRC20||''},price:env.PRICE||'5'});
  }
  if(a==='admin_list' || a==='admin_set'){
   if(!env.ADMIN_PASSWORD || !await same(String(b.password||''),env.ADMIN_PASSWORD)) return json({error:'Wrong admin password or ADMIN_PASSWORD is not configured.'},401);
   if(a==='admin_list') return json({users:await db(env,'users?select=id,name,phone,reg_no,approved,pay_status,txid,net,created_at&order=created_at.desc')});
   const ops={approve:{approved:true},reject:{approved:false},confirm:{pay_status:'confirmed'},unpay:{pay_status:'none',txid:null,net:null}}; const update=ops[b.op];
   if(!update || !/^[0-9a-f-]{36}$/i.test(String(b.id||''))) return json({error:'Invalid admin request.'},400);
   await db(env,'users?id=eq.'+encodeURIComponent(b.id),{method:'PATCH',body:JSON.stringify(update)}); return json({ok:true});
  }
  return json({error:'Unknown action.'},400);
 } catch(err) {
  console.error('Skillora API error:',err?.message||err);
  const msg=String(err?.message||'');
  if(msg.includes('Database is not configured')) return json({error:msg},503);
  if(msg.includes('SUPABASE') || msg.includes('Database request failed')) return json({error:'Database connection failed. Check Cloudflare environment variables and run supabase.sql in your Supabase project.'},503);
  return json({error:'Request could not be completed. Check your database setup and try again.'},500);
 }
}
