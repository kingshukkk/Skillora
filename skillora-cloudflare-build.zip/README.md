# Skillora — Cloudflare Pages build

## Important
This project uses Cloudflare Pages Functions (`functions/api.js`) for `/api`. It is not the Netlify Functions version. Registration/login require a Supabase project and Cloudflare environment variables; uploading static files alone will not make accounts work.

## Deploy on Cloudflare Pages
1. Open https://dash.cloudflare.com/ and create a Pages project. Use **Direct Upload** for a quick static preview, or connect a Git repository for the full Pages Functions build.
2. For a Git-connected Pages project, keep `public/` as the build output directory and `functions/api.js` at the project root. Do not put `functions/` inside `public/`.
3. Create a project at https://supabase.com/ and open SQL Editor. Run the full contents of `supabase.sql`.
4. Cloudflare Pages → Settings → Variables and Secrets. Add these as **secrets** where applicable:
   - `SUPABASE_URL`: your Supabase project URL
   - `SUPABASE_KEY`: Supabase service-role/secret key (never expose it in frontend code)
   - `JWT_SECRET`: random secret at least 32 characters long
   - `ADMIN_PASSWORD`: a strong admin password
   - `USDT_BEP20`: receiving wallet address, if using this existing USDT payment flow
   - `USDT_TRC20`: receiving wallet address, if using this existing USDT payment flow
   - `PRICE`: payment amount in USDT (defaults to 5)
5. Save variables and redeploy. Test account registration and login. Admin page: `/admin.html`.

## Notes
- This build moves the API to Cloudflare Pages Functions and uses Web Crypto (PBKDF2 + HMAC), so the old Netlify Node function is not used.
- If a project was previously used with the Netlify version, old password hashes made with scrypt will not validate in this version; test with a newly created account or reset those passwords.
- The existing payment screen is the original USDT TXID flow. UPI QR payments and real rewards/payouts are not yet implemented by this package. Do not advertise users, ratings, guaranteed income, or payout history unless those claims are true.
- Never paste secret keys into the public frontend or share them in screenshots.
