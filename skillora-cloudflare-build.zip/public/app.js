var T=null,U=null,CFG={},V=document.getElementById('view'),A=document.getElementById('app');
try{T=localStorage.getItem('sk_t')}catch(e){}
function saveT(t){T=t;try{t?localStorage.setItem('sk_t',t):localStorage.removeItem('sk_t')}catch(e){}}
function api(a,d){d=d||{};d.action=a;d.token=T;return fetch('/api',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}).then(function(r){return r.json()}).catch(function(){return{error:'No connection. Try again.'}})}
function $(i){return document.getElementById(i).value.trim()}
function esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML}
function err(m){document.getElementById('e').textContent=m}
function refresh(){if(!T){U=null;return Promise.resolve()}return api('me').then(function(r){if(r.user){U=r.user;CFG=r}else{U=null;if(r.error&&/log in/.test(r.error))saveT(null)}})}
function closeApp(){A.classList.remove('on')}
function logout(){saveT(null);U=null;closeApp()}
function go(v){document.getElementById('nav').classList.remove('open');A.classList.add('on');window.scrollTo(0,0);V.innerHTML='<p style="color:var(--mute)">Loading…</p>';
refresh().then(function(){var u=U;
if((v==='dash'||v==='earn'||v==='pay')&&!u)v='login';
if((v==='login'||v==='reg')&&u)v='dash';
var h='',g=function(x){return "go(\\'"+x+"\\')"};
if(v==='login')h='<h2>Login</h2><label>Mobile number</label><input id="p" inputmode="numeric" maxlength="10"><label>Password</label><input id="w" type="password"><div class="err" id="e"></div><button onclick="login()">Login</button><button class="g" onclick="'+g('reg')+'">Create new account</button><button class="g" onclick="closeApp()">Back to home</button>';
if(v==='reg')h='<h2>Create account</h2><label>Full name</label><input id="n"><label>Mobile number</label><input id="p" inputmode="numeric" maxlength="10"><label>Password (min 6 characters)</label><input id="w" type="password"><div class="err" id="e"></div><button onclick="reg()">Register</button><button class="g" onclick="'+g('login')+'">I already have an account</button>';
if(v==='dash')h='<h2>Hi, '+esc(u.name)+'</h2><label>Your registration number</label><div class="reg">'+esc(u.reg_no)+'</div><p>Account status: '+(u.approved?'<span class="pill ok">Approved</span>':'<span class="pill wait">Waiting for approval</span>')+'</p><p style="color:var(--mute)">Learning is open now. Earning opens after approval and a one-time payment.</p><button onclick="'+g('earn')+'">Go to Earn</button><button class="g" onclick="logout()">Log out</button><button class="g" onclick="closeApp()">Back to home</button>';
if(v==='earn'){
 if(!u.approved)h='<h2>Earn</h2><p><span class="pill wait">Waiting for approval</span></p><p style="color:var(--mute)">Your account needs approval before you can earn. Check back soon.</p>';
 else if(u.pay_status==='none')h='<h2>Unlock Earn</h2><p style="color:var(--mute)">One-time payment. Pay once and Earn stays unlocked on this account.</p><div class="reg">₹'+esc(CFG.price)+'</div><button onclick="'+g('pay')+'">Continue to payment</button>';
 else if(u.pay_status==='submitted')h='<h2>Earn</h2><p><span class="pill wait">Payment being checked</span></p><p style="color:var(--mute)">We will unlock Earn once your payment is confirmed.</p>';
 else h='<h2>Earn</h2><p><span class="pill ok">Unlocked</span></p><p style="color:var(--mute)">Your earning dashboard goes here: tasks, referrals, wallet and withdrawals.</p>';
 h+='<button class="g" onclick="'+g('dash')+'">Back to my account</button>'}
if(v==='pay'){
 if(!u.approved||u.pay_status!=='none'){go('earn');return}
 h='<h2>Pay with USDT</h2><p style="color:var(--mute)">Send exactly '+esc(CFG.price)+' USDT on the network you choose. Sending on a different network can lose your funds.</p><label>Network</label><select id="net" onchange="showAddr()"><option value="BEP20">USDT - BEP20 (BNB Smart Chain)</option><option value="TRC20">USDT - TRC20 (Tron)</option></select><label>Wallet address</label><div class="reg" id="ad" style="font-size:.85rem;word-break:break-all">'+esc((CFG.addr||{}).BEP20||'')+'</div><label>Transaction hash (TXID) after payment</label><input id="t"><div class="err" id="e"></div><button onclick="pay()">I have paid</button><button class="g" onclick="'+g('earn')+'">Cancel</button>'}
V.innerHTML=h})}
function login(){api('login',{phone:$('p'),password:document.getElementById('w').value}).then(function(r){if(r.error)return err(r.error);saveT(r.token);go('dash')})}
function reg(){api('register',{name:$('n'),phone:$('p'),password:document.getElementById('w').value}).then(function(r){if(r.error)return err(r.error);saveT(r.token);go('dash')})}
function pay(){api('pay',{net:document.getElementById('net').value,txid:$('t')}).then(function(r){if(r.error)return err(r.error);go('earn')})}

function showAddr(){document.getElementById('ad').textContent=(CFG.addr||{})[document.getElementById('net').value]||''}
