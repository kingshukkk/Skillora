create table users (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text unique not null,
  pass_hash text not null,
  reg_no text unique not null,
  approved boolean not null default false,
  pay_status text not null default 'none',
  txid text,
  net text,
  created_at timestamptz not null default now()
);
alter table users enable row level security;
create unique index users_txid_key on users(txid) where txid is not null;
